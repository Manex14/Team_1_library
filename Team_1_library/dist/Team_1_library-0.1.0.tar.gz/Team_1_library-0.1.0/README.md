Team_1_library

Python library with advaced functions for missing values imputations using clustering and statistical techniques, as well as outlier corrections.

Characteristics

- Missing value imputation with clustering (K-Means).
- Missing value imputation with statistical values (mean,median,mode).
- Outlier detection and correction to mean with Z-score technique.
- Empty column elimination with customizable threshold.
- Low variance column elimination with customizable threshold.

Usage:

The usage of this library functions are explained in the file 'USAGE.md'. An example of the use is included in the file 'example_usage.py'.

Instalation

To install the library, navigate to the folder containing 'Team_1_library' in your preferred environment and install it using 'pip':
```bash
pip install ./path/to/the/library

Make sure you have the required dependencies installed:
```bash
pip install pandas scipy numpy scikit-learn

 