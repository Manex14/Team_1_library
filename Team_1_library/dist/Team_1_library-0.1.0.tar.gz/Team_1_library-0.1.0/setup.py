from setuptools import setup, find_packages

setup(
name="Team_1_library",
version="0.1.0",
description="Data prerpocess library with missing value imputation and outlier correction functions.",
long_description=open("README.md").read(),
long_description_content_type="text/markdown",
author="Jokin Agirre, Irene Alvarez, Uxue Auzmendi, Jon Lorenzo, Manex Ugarte ",
author_email="manex.ugarte@alumni.mondragon.edu",
url="",
packages=find_packages(),
install_requires=[
        "pandas",
        "scipy",
        "numpy",
        "sklearn"
    ],
classifiers=[
    "Programming Language :: Python :: 3",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
],
python_requires=">=3.8",
)